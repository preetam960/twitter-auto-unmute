function unmuteAllTwitterVideos() {
    chrome.storage.sync.get(["enabled"], (result) => {
        if (!result.enabled) return;

        const videos = document.querySelectorAll('video');
        videos.forEach(video => {
            if (video.muted) {
                video.muted = false;
                video.volume = 1;
                video.defaultMuted = false;
            }
        });
    });
}

unmuteAllTwitterVideos();

const observer = new MutationObserver(() => {
    unmuteAllTwitterVideos();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});