# Changelog

## [1.1] - 2025-05-03
### Added
- Popup with toggle switch to enable/disable auto-unmute
- Icon support for toolbar and extension pages

## [1.0] - 2025-05-02
### Added
- Initial release: auto-unmutes all Twitter videos using content script
