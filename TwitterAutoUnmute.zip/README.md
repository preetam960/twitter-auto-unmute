# Twitter Auto Unmute Chrome Extension

Automatically unmutes all videos on Twitter (X) as you scroll. Toggle on/off from the toolbar.

## Features

- Unmutes all videos on Twitter and X.com
- Toggle the feature on/off from popup
- Simple, lightweight, and privacy-respecting

## Installation

1. Download or clone the repository.
2. Go to `chrome://extensions/` in Chrome.
3. Enable "Developer mode".
4. Click "Load unpacked" and select the folder.
5. Enjoy auto-unmuted videos!

## License

MIT License
